# G3 key command and exit-code index

| # | Actual command | Exit | Log / evidence |
|---|---|---:|---|
| 1 | `.venv/bin/python scripts/validate_g0_artifacts.py` | 0 | G0 saved-artifact check |
| 2 | `.venv/bin/python scripts/g1_validate.py` | 0 | G1 saved-artifact check |
| 3 | `.venv/bin/python scripts/run_g2.py` (pre-G3 state) | 0 | G2 preserved |
| 4 | `scons NO_STORAGE=0 NO_LIBRARY=1` (G3 build, cwd `simulator`) | 0 | `logs/g3_build.log`; G3 binary `6b31ba...` |
| 5 | `PHASE1_ECC_OUT=... PHASE1_G3_WITNESS=... ./sim --gtest_filter='Phase1Ecc.*:Phase1Storage.*'` | 0 | 3/3 tests; `runs/g3/ecc_cpp_exhaustive.csv`, `f1_witness.json` |
| 6 | `.venv/bin/python -m pytest -q tests/test_ecc_reference.py` | 0 | 17 passed; `logs/g3_ecc_python.log` |
| 7 | `.venv/bin/python scripts/run_g3.py` | 0 | 15/15 checks; `results/g3/validation.json` |
| 8 | `./sim --gtest_filter='PIMKernelFixture.*'` | 0 | `runs/g3/upstream-tests.xml` 5/5 |
| 9 | `./sim --gtest_filter='PIMBenchFixture.add'` | 1 | known 1.98597 < 2.0; `runs/g3/pimbench_add.log` |
| 10 | generate cumulative G3 `environment/source.patch`; preserve `source_g2.patch` | 0 | `logs/g3_patch.log`; patch `933b32...` |
| 11 | clean worktree `git worktree add --detach`, `git apply --check`, `git apply` | 0 | `logs/g3_clean_worktree.log`, `g3_clean_apply.log` |
| 12 | clean copy `scons NO_STORAGE=0 NO_LIBRARY=1` | 0 | `logs/g3_clean_build.log`; clean binary `97809a...` |
| 13 | clean copy ECC/Storage tests + Python cross-check | 0 | `runs/g3/clean_replay/` |
| 14 | clean copy `PIMKernelFixture.*` | 0 | `runs/g3/clean_replay/upstream-tests.xml` 5/5 |
| 15 | clean independent validation | 0 | `logs/g3_clean_smoke.log`, `runs/g3/clean_replay/validation.json` |
| 16 | generate `environment/g3.lock.json` | 0 | `logs/g3_lock.log` |

No test threshold or expected result was changed.
