# G6 key command and exit-code index

| # | Actual command | Exit | Log / evidence |
|---|---|---:|---|
| 1 | `scons NO_STORAGE=0 NO_LIBRARY=1` (G6 build, cwd `simulator`) | 0 | `logs/g6_build.log`; G6 binary `13cf8a...` |
| 2 | `.venv/bin/python scripts/run_g6.py` (16 pause/quiesce cases) | 0 | `logs/g6_run.log`; `results/g6/validation.json` |
| 3 | `./sim --gtest_filter='PIMKernelFixture.*'` | 0 | `runs/g6/upstream-tests.xml` 5/5 |
| 4 | `./sim --gtest_filter='Phase1Ecc.*:Phase1Storage.*'` | 0 | `runs/g6/ecc_regression.log` 3/3 |
| 5 | `./sim --gtest_filter='PIMBenchFixture.add'` | 1 | known 1.98597 < 2.0; `runs/g6/pimbench_add.log` |
| 6 | Generate cumulative G6 patch; preserve `source_g6.patch` | 0 | `logs/g6_patch.log`; patch `53b188...` |
| 7 | Clean worktree `git apply --check` / `git apply` | 0 | `logs/g6_clean_worktree.log`, `g6_clean_apply.log` |
| 8 | Clean copy `scons NO_STORAGE=0 NO_LIBRARY=1` | 0 | `logs/g6_clean_build.log`; clean binary `7f531f...` |
| 9 | Clean G6 16 cases + ECC + PIMKernel | 0 | `runs/g6/clean_replay/`, `logs/g6_clean_smoke.log` |
| 10 | Final audit | 0 | `logs/g6_final_audit.log` |

No expected threshold was changed. The G6 two-channel smoke uses independent
host traffic; it is not a full W1/W3 kernel pair.
