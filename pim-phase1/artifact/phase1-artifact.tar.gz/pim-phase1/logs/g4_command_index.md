# G4 key command and exit-code index

| # | Actual command | Exit | Log / evidence |
|---|---|---:|---|
| 1 | `.venv/bin/python scripts/validate_g0_artifacts.py` | 0 | G0 saved-artifact check |
| 2 | `.venv/bin/python scripts/g1_validate.py` | 0 | G1 saved-artifact check |
| 3 | `.venv/bin/python scripts/run_g3.py` | 0 | G3 pre-G4 check |
| 4 | `scons NO_STORAGE=0 NO_LIBRARY=1` (G4 build, cwd `simulator`) | 0 | `logs/g4_build.log`; G4 binary `1d3aa6...` |
| 5 | `.venv/bin/python scripts/run_g4.py` (207 P1-A/P1-B smoke cases) | 0 | `logs/g4_run.log`; `results/g4/validation.json` |
| 6 | `./sim --gtest_filter='PIMKernelFixture.*'` | 0 | `runs/g4/upstream-tests.xml` 5/5 |
| 7 | `./sim --gtest_filter='Phase1Ecc.*:Phase1Storage.*'` | 0 | `runs/g4/ecc_regression.log` 3/3 |
| 8 | `./sim --gtest_filter='PIMBenchFixture.add'` | 1 | known 1.98597 < 2.0; `runs/g4/pimbench_add.log` |
| 9 | Generate cumulative G4 patch; preserve `source_g4.patch` | 0 | `logs/g4_patch.log`; patch `9c7331...` |
| 10 | Clean worktree `git apply --check` / `git apply` | 0 | `logs/g4_clean_worktree.log`, `g4_clean_apply.log` |
| 11 | Clean copy `scons NO_STORAGE=0 NO_LIBRARY=1` | 0 | `logs/g4_clean_build.log`; clean binary `0b63dd...` |
| 12 | Clean G4 selected smoke + ECC + PIMKernel | 0 | `runs/g4/clean_replay/`, `logs/g4_clean_smoke.log` |
| 13 | Final audit | 0 | `logs/g4_final_audit.log` |

No expected threshold was changed. The P1-A/P1-B smoke is not the full paper
matrix; it is the G4 acceptance subset.
