# G5 key command and exit-code index

| # | Actual command | Exit | Log / evidence |
|---|---|---:|---|
| 1 | `.venv/bin/python scripts/run_g4.py` | 0 | G4 preserved before G5 |
| 2 | `scons NO_STORAGE=0 NO_LIBRARY=1` (G5 build, cwd `simulator`) | 0 | `logs/g5_build.log`; G5 binary `1a527f...` |
| 3 | `.venv/bin/python scripts/run_g5.py` (12 W1 cases + runtime test) | 0 | `logs/g5_run.log`; `results/g5/validation.json` |
| 4 | `./sim --gtest_filter='Phase1Runtime.*'` | 0 | `runs/g5/runtime_tests.log`; same-cycle/stale handle test |
| 5 | `./sim --gtest_filter='PIMKernelFixture.*'` | 0 | `runs/g5/upstream-tests.xml` 5/5 |
| 6 | `./sim --gtest_filter='Phase1Ecc.*:Phase1Storage.*'` | 0 | `runs/g5/ecc_regression.log` 3/3 |
| 7 | `./sim --gtest_filter='PIMBenchFixture.add'` | 1 | known 1.98597 < 2.0; `runs/g5/pimbench_add.log` |
| 8 | Generate cumulative G5 patch; preserve `source_g5.patch` | 0 | `logs/g5_patch.log`; patch `f3d898...` |
| 9 | Clean worktree `git apply --check` / `git apply` | 0 | `logs/g5_clean_worktree.log`, `g5_clean_apply.log` |
| 10 | Clean copy `scons NO_STORAGE=0 NO_LIBRARY=1` | 0 | `logs/g5_clean_build.log`; clean binary `5ca0c6...` |
| 11 | Clean G5 12 cases + runtime + ECC + PIMKernel | 0 | `runs/g5/clean_replay/`, `logs/g5_clean_smoke.log` |
| 12 | Final audit | 0 | `logs/g5_final_audit.log` |

The G5 same-cycle unit test covers report arrival one cycle before, in the same
cycle as, and one cycle after the planned publish. No expected threshold was
changed.
