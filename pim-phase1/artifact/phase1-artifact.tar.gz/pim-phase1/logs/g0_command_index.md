# G0 command and exit-code index

关键命令均从 `pim-phase1/` 或其中注明的目录执行。退出码取自实际运行日志；没有执行的命令不列入。辅助操作（如 `cp HANDOFF.md`、`chmod`）不逐条展开。

| # | 实际命令 | 退出码 | 日志 / 证据 |
|---|---|---|---|
| 1 | `sudo apt-get update` + `sudo apt-get install -y git build-essential scons libgtest-dev python3 python3-venv python3-pip poppler-utils` | 0 | `logs/g0_apt_install.log` |
| 2 | `git clone https://github.com/SAITPublic/PIMSimulator.git simulator`（第一次，180 s 上限） | 143（SIGTERM） | 会话输出显示 `fetch-pack: unexpected disconnect`；该次输出未单独落盘 |
| 3 | `git clone --depth 1 --branch dev https://github.com/SAITPublic/PIMSimulator.git simulator` | 0 | `logs/g0_clone.log` |
| 4 | `git -C simulator checkout --detach 3703d1f19c8f027360cc33a3243eb271e3bb6898` | 0 | `logs/g0_clone.log` |
| 5 | `git -C simulator rev-parse HEAD` | 0 | `logs/g0_clone.log`（`3703d1f...`） |
| 6 | `git ls-remote https://github.com/SAITPublic/PIMSimulator.git refs/heads/dev` | 0 | `logs/g0_ref_check.log` |
| 7 | `python3 -m venv .venv`；`.venv/bin/python -m pip install ...`；`pip freeze` | 0 | `logs/g0_python_env.log` |
| 8 | `scons NO_STORAGE=0 NO_LIBRARY=1`（首次） | 0 | `logs/g0_build.log` |
| 9 | `./sim --gtest_list_tests` | 0 | `logs/g0_gtest_list.log` |
| 10 | `./sim --gtest_filter='PIMKernelFixture.*' --gtest_output=xml:../runs/baseline/upstream-tests.xml` | 0 | `logs/g0_upstream_tests.*`、`runs/baseline/manual_first_run/` |
| 11 | `./sim --gtest_output=xml:../runs/baseline/upstream-all-tests.xml` | 1 | `logs/g0_upstream_all.*`、`runs/baseline/upstream-all-tests.xml` |
| 12 | `./sim --gtest_filter='PIMBenchFixture.add'`（隔离复现） | 1 | `logs/g0_pimbench_add_isolated.log` |
| 13 | 临时副本 `scons NO_STORAGE=1 NO_LIBRARY=1` + `./sim --gtest_filter='PIMBenchFixture.add'` | 构建 0；测试 1 | `logs/g0_diag_nostorage1.log`（仅诊断，不作为交付构建） |
| 14 | `./scripts/build.sh --clean` | 0 | `logs/build_20261115T122721Z.log` |
| 15 | `./scripts/run_baseline.sh` | 0 | `logs/baseline_20261115T122735Z.log`、`runs/baseline/upstream-tests.xml` |
| 16 | `cd simulator && git ls-files -z \| sort -z \| xargs -0 sha256sum > ../environment/upstream-files.sha256` | 0 | `logs/g0_source_manifest.log` |
| 17 | `.venv/bin/python scripts/capture_environment.py` | 0 | `logs/g0_environment.log`、`environment/environment.{txt,json}` |
| 18 | `.venv/bin/python scripts/lock_upstream.py` | 0 | `logs/g0_upstream_lock.log`、`environment/upstream.lock.json` |
| 19 | `./scripts/bootstrap.sh --check-only` | 0 | `logs/bootstrap_20261115T122802Z.log` |
| 20 | `.venv/bin/python scripts/validate_g0.py` | 0 | `logs/g0_validation.log`、`environment/g0_validation.json` |
| 21 | `git -C simulator apply --check ../environment/source.patch`（空文件试验） | 128 | 见 `docs/implementation_log.md` §7；空文件已删除，未伪造补丁 |
| 22 | `.venv/bin/python` JSON 语法检查 + `environment/g0_validation.json` 汇总 + `git status` + `bash -n` | 0 | `logs/g0_final_audit.log` |

说明：第 2 行的第一次 clone 失败后删除了不完整目录，没有把失败尝试写成成功；`logs/g0_clone.log` 只对应第 3–5 行的成功重试。
