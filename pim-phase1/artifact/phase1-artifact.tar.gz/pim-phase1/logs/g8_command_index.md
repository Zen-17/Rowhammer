# G8 key command and exit-code index

| # | Actual command | Exit | Log / evidence |
|---|---|---:|---|
| 1 | `.venv/bin/python scripts/calibrate_g8.py` | 0 | `logs/g8_calibration.log`; T_ref 731/3339 (P1-C), 804/4130 (P1-F) |
| 2 | `.venv/bin/python scripts/expand_suite.py --suite configs/suite_paper.yaml` | 0 | `logs/g8_expand.log`; 2602 cases, 7 expected negatives |
| 3 | `.venv/bin/python scripts/run_suite.py --manifest configs/generated/paper-manifest.json --jobs 8` | 0 | `logs/g8_run_full.log`; `results/g8/validation.json` |
| 4 | `.venv/bin/python scripts/aggregate.py --runs runs/paper --out results` | 0 | `logs/g8_aggregate.log`; `results/validation_summary.json` |
| 5 | `./sim --gtest_filter='PIMKernelFixture.*'` | 0 | `runs/g8/upstream-tests.xml`, 5/5 |
| 6 | `./sim --gtest_filter='Phase1Ecc.*:Phase1Storage.*'` | 0 | `runs/g8/ecc_regression.log`, 3/3 |
| 7 | `./sim --gtest_filter='Phase1Runtime.*:Phase1Contract.*:Phase1Checkpoint.*'` | 0 | `runs/g8/runtime_contract.log` |
| 8 | `./sim --gtest_filter='PIMBenchFixture.add'` | 1 | known 1.98597 < 2.0; `runs/g8/pimbench_add.log` |
| 9 | Generate cumulative G8 patch; preserve `source_g8.patch` and `source_g7.patch` | 0 | patch `93daf08c...`; G7 snapshot `d94c5c...` |
| 10 | Clean worktree `git apply --check` / `git apply` | 0 | `logs/g8_clean_worktree.log`, `logs/g8_clean_apply.log` |
| 11 | Clean copy `scons NO_STORAGE=0 NO_LIBRARY=1` | 0 | `logs/g8_clean_build.log`; clean binary `71b11534...` |
| 12 | Clean selected G8 smoke (each group at least one case) | 0 | `runs/g8/clean_replay/validation.json`, `logs/g8_clean_smoke.log` |
| 13 | Clean `PIMKernelFixture.*` / ECC / `PIMBenchFixture.add` | 0 / 0 / 1 | `runs/g8/clean_replay/` |
| 14 | G0/G1 validators, patch reverse-check, `git diff --check` | 0 | `logs/g8_final_audit.log` |
| 15 | `.venv/bin/python scripts/run_suite.py --jobs 8 --resume` | 0 | `logs/g8_resume_full.log`; all 2602 hashes matched and skipped |

No threshold was changed. The 7 expected negatives are the five G7 status
cases plus `NO_INPUT_RESTORE` and `NO_STATE_RESET`. `PIMBenchFixture.add`
remains the known upstream performance failure and is not counted as a G8 pass.
