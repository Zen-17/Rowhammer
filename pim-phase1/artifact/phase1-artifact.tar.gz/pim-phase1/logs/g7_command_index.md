# G7 key command and exit-code index

| # | Actual command | Exit | Log / evidence |
|---|---|---:|---|
| 1 | `scons NO_STORAGE=0 NO_LIBRARY=1` (G7 build, cwd `simulator`) | 0 | `logs/g7_build.log`; G7 binary `0bb330...` |
| 2 | `.venv/bin/python scripts/run_g7.py` (20 report + 4 probe + 2 negative controls + 5 statuses) | 0 | `logs/g7_run.log`; `results/g7/validation.json` 31/31 |
| 3 | `./sim --gtest_filter='PIMKernelFixture.*'` | 0 | `runs/g7/upstream-tests.xml` 5/5 |
| 4 | `./sim --gtest_filter='Phase1Ecc.*:Phase1Storage.*'` | 0 | `runs/g7/ecc_regression.log` 3/3 |
| 5 | `./sim --gtest_filter='Phase1Checkpoint.*'` | 0 | `runs/g7/checkpoint_unit.log` 1/1 |
| 6 | `./sim --gtest_filter='PIMBenchFixture.add'` | 1 | known 1.98597 < 2.0; `runs/g7/pimbench_add.log` |
| 7 | Generate cumulative G7 patch; preserve `source_g7.patch` and `source_g6.patch` | 0 | patch `d94c5c...`; G6 snapshot `53b188...` |
| 8 | Clean worktree `git apply --check` / `git apply` | 0 | `logs/g7_clean_worktree.log`, `logs/g7_clean_apply.log` |
| 9 | Clean copy `scons NO_STORAGE=0 NO_LIBRARY=1` | 0 | `logs/g7_clean_build.log`; clean binary `b24a34...` |
| 10 | Clean G7 31 cases + PIMKernel + ECC + checkpoint | 0 | `runs/g7/clean_replay/`, `logs/g7_clean_smoke.log` |
| 11 | Clean `PIMBenchFixture.add` | 1 | known 1.98597 < 2.0; `runs/g7/clean_replay/pimbench_add.log` |
| 12 | G0/G1 validators, patch reverse-check, `git diff --check` | 0 | `logs/g7_final_audit.log` |

No expected threshold was changed. Report-triggered positive cases inject one F1
storage bit; explicit `RECOVERY_PROBE` cases do not inject a storage fault and
are labeled separately. `PIMBenchFixture.add` remains the known upstream
performance failure and is not counted as a G7 pass.
