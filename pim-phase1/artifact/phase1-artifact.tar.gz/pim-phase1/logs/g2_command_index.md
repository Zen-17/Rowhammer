# G2 key command and exit-code index

All commands were run from `pim-phase1/` unless the working directory is shown.

| # | Actual command | Exit | Log / evidence |
|---|---|---:|---|
| 1 | `.venv/bin/python scripts/validate_g0_artifacts.py` | 0 | G0 saved-artifact check |
| 2 | `.venv/bin/python scripts/g1_validate.py` | 0 | G1 saved-artifact check |
| 3 | `scons NO_STORAGE=0 NO_LIBRARY=1` (G2 build, cwd `simulator`) | 0 | `logs/g2_build.log`; G2 binary `f54c8a...` |
| 4 | `.venv/bin/python scripts/run_g2.py` (four feeder cases) | 0 | `logs/g2_run.log`; `runs/g2/run_manifest.json` |
| 5 | `.venv/bin/python scripts/validate_run.py --run-dir ...` (called by runner) | 0 | per-run `validation.json`, `metrics.json` |
| 6 | `.venv/bin/python -m pytest -q tests/test_schema.py` | 0 | 10 passed; `logs/g2_schema_test.log` |
| 7 | negative control: copy ext_on run and duplicate event_seq, then `validate_run.py` | 1 | `logs/g2_negative_sequence.log`; expected failure |
| 8 | `./sim --gtest_filter='PIMKernelFixture.*' --gtest_output=xml:../runs/g2/upstream-tests.xml` | 0 | 5/5 PASS; `runs/g2/upstream-tests.xml` |
| 9 | `./sim --gtest_filter='PIMBenchFixture.add'` | 1 | known 1.98597 < 2.0; `runs/g2/pimbench_add.log` |
| 10 | `PHASE1_SYSTEM_INI=... ./sim --gtest_filter=Phase1Contract.FeederRetainsOnControllerRejection` | 0 | `logs/g2_feeder_rejection.log` |
| 11 | generate cumulative `environment/source.patch` from fixed commit; preserve `source_g1.patch` | 0 | `logs/g2_patch.log`; patch `2b7b65...` |
| 12 | clean worktree: `git worktree add --detach`, `git apply --check`, `git apply` | 0 | `logs/g2_clean_worktree.log`, `g2_clean_apply.log` |
| 13 | clean copy `scons NO_STORAGE=0 NO_LIBRARY=1` | 0 | `logs/g2_clean_build.log`; clean binary `0d8723...` |
| 14 | clean copy G2 ext_off/on smoke | 0 | `logs/g2_clean_smoke.log`; `runs/g2/clean_replay/validation.json` |
| 15 | clean copy `PIMKernelFixture.*` | 0 | `runs/g2/clean_replay/upstream-tests.xml` 5/5 |
| 16 | final G1/G0 regression | 0 | `logs/g2_regression.log` |
| 17 | generate `environment/g2.lock.json` | 0 | `logs/g2_lock.log` |

The schema validator failure observed in the first ext_on validation was due to
treating CSV numeric fields as strings; it was fixed before the final G2 run.
The broadcast/control `actual_bank` classification was also corrected before
the final run. No test threshold or expected value was relaxed.
