# G1 key command and exit-code index

All commands were run from `pim-phase1/` unless the working directory is shown.
The full raw output stays in the referenced logs; this file is only an index.

| # | Actual command | Exit | Log / evidence |
|---|---|---:|---|
| 1 | `.venv/bin/python scripts/validate_g0.py` | 0 | G0 18/18 PASS before G1 work |
| 2 | `scons NO_STORAGE=0 NO_LIBRARY=1` (first G1 compile) | 2 | first failure: `pendingTransactions` member/const errors; later successful log at `logs/g1_build.log` |
| 3 | `scons NO_STORAGE=0 NO_LIBRARY=1` (final G1 build, cwd `simulator`) | 0 | `logs/g1_build.log`; binary `be9f6a...` |
| 4 | `PHASE1_CONFIG=.../address_mapping/1ch/params.ini PHASE1_OUT=... ./sim --gtest_filter=Phase1Fixture.RunCase` | 0 | `runs/g1/address_mapping/1ch/stdout.log`, `address_mapping.{csv,json}` |
| 5 | same for 2-channel address mapping | 0 | `runs/g1/address_mapping/2ch/` |
| 6 | `PHASE1_CONFIG=.../w0_1ch_direct/params.ini PHASE1_OUT=... ./sim --gtest_filter=Phase1Fixture.RunCase` | 0 | `runs/g1/w0_1ch_direct/` |
| 7 | same for W0 feeder | 0 | `runs/g1/w0_1ch_feeder/` |
| 8 | `.venv/bin/python scripts/run_g1.py` (16 cases, separate processes) | 0 | `logs/g1_run.log`; `runs/g1/run_manifest.json` |
| 9 | `.venv/bin/python scripts/g1_validate.py` | 0 | `logs/g1_validation.log`; 10/10 checks PASS |
| 10 | `./sim --gtest_filter='PIMKernelFixture.*' --gtest_output=xml:../runs/g1/upstream-tests.xml` | 0 | `runs/g1/upstream-tests.xml`, tests=5 failures=0 |
| 11 | `./sim --gtest_filter='PIMBenchFixture.add'` | 1 | `runs/g1/pimbench_add.log`; known 1.98597 < 2.0 |
| 12 | `PHASE1_SYSTEM_INI=... ./sim --gtest_filter=Phase1Contract.FeederRetainsOnControllerRejection` | 0 | `logs/g1_feeder_rejection.log` |
| 13 | `git -C simulator add -N ...` + `git diff --binary > environment/source.patch` + `git reset -q` | 0 | `logs/g1_patch.log`; patch SHA256 `629a36...` |
| 14 | `git -C /tmp/opencode/pim-g1-clean apply --check environment/source.patch` after reset to fixed commit | 0 | `logs/g1_patch.log` |
| 15 | `git -C /tmp/opencode/pim-g1-clean apply environment/source.patch` | 0 | `logs/g1_patch.log` |
| 16 | `scons NO_STORAGE=0 NO_LIBRARY=1` in clean copy | 0 | `logs/g1_clean_build.log`; clean binary `1eca462...` |
| 17 | clean smoke: address 1/2ch + W1 nt1 seed0 direct/feeder + `PIMKernelFixture.*` + feeder admission | 0 | `logs/g1_clean_smoke.log`, `runs/g1/clean_replay/` |
| 18 | clean independent validation | 0 | `logs/g1_clean_validation.log`, `runs/g1/clean_replay/validation.json` |
| 19 | `.venv/bin/python` G1 lock generation | 0 | `logs/g1_lock.log`, `environment/g1.lock.json` |
| 20 | clean copy reset/reapply/rebuild after an already-patched apply-check | 0 | `logs/g1_patch.log`, `logs/g1_clean_build_after_patch.log` |
| 21 | `.venv/bin/python scripts/validate_g0_artifacts.py` | 0 | `logs/g1_g0_artifact_validation.log`, `environment/g0_artifact_validation.json` |

The earlier `git apply --check` done against a clean copy that **already had the patch
applied** returned 1 with “already exists” errors; that was an expected state, not a
patch failure. The clean copy was reset to the fixed commit, cleaned, and the check
and application were rerun with exit 0 in `logs/g1_patch.log`.
